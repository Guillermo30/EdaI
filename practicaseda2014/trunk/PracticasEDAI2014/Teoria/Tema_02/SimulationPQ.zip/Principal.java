package org.eda1.SimulationPQ;

public class Principal {
	public static void main(String[] args) {
		Simulation obj = new Simulation();
		obj.startSimulation();
	}
}
