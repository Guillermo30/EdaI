package org.eda1.SimulationPQ;

import java.io.File;
import java.util.PriorityQueue;

import org.eda1.utilidades.Less;

public class EventDrivenSimulation {
	private PriorityQueue<Event> eventPQ = new PriorityQueue<Event>(5, new Less<Event>());
		
	public void pushEvent(Event e) {
		eventPQ.add(e);
	}

	public void run() {
		while (!eventPQ.isEmpty()) {
			Event nextEvent = eventPQ.poll();	//eventQueue.removeMin();
			nextEvent.doEvent();
		}
	}
}
